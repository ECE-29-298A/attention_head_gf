import pya
ly = pya.Layout()
ly.read("/Users/samuelzhang/ttsetup/pdk/ciel/gf180mcu/versions/54435919abffb937387ec956209f9cf5fd2dfbee/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/gds/gf180mcu_fd_sc_mcu7t5v0.gds")
print("dbu", ly.dbu, "cells", ly.cells())
for n in ["gf180mcu_fd_sc_mcu7t5v0__mux2_1","gf180mcu_fd_sc_mcu7t5v0__mux2_2","gf180mcu_fd_sc_mcu7t5v0__inv_1","gf180mcu_fd_sc_mcu7t5v0__filltie","gf180mcu_fd_sc_mcu7t5v0__endcap","gf180mcu_fd_sc_mcu7t5v0__dffq_1"]:
    c = ly.cell(n)
    print(n, c.dbbox(), "children", c.child_cells())
li = [ (ly.get_info(i).layer, ly.get_info(i).datatype) for i in ly.layer_indexes()]
print(sorted(li))
